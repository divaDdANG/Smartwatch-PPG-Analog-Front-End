Version 4
SymbolType BLOCK
RECTANGLE Normal -96 -56 96 56
WINDOW 0 0 -56 Bottom 2
PIN -96 0 LEFT 8
PINATTR PinName Control
PINATTR SpiceOrder 1
PIN -96 32 LEFT 8
PINATTR PinName Vdd
PINATTR SpiceOrder 2
PIN -96 -32 LEFT 8
PINATTR PinName Vin
PINATTR SpiceOrder 3
PIN 96 0 RIGHT 8
PINATTR PinName Out
PINATTR SpiceOrder 4
