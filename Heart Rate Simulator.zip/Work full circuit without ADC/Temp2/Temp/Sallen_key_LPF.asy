Version 4
SymbolType BLOCK
RECTANGLE Normal -64 -56 80 56
WINDOW 0 8 -56 Bottom 2
PIN -64 0 LEFT 8
PINATTR PinName Vdd
PINATTR SpiceOrder 1
PIN -64 -32 LEFT 8
PINATTR PinName Vin
PINATTR SpiceOrder 2
PIN -64 32 LEFT 8
PINATTR PinName Vss
PINATTR SpiceOrder 3
PIN 80 0 RIGHT 8
PINATTR PinName Vout
PINATTR SpiceOrder 4
