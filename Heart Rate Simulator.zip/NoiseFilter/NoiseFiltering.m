clear; clc; close all;

%% =========================================================
%  PARAMETERS
fs       = 500;     % Sampling rate (Hz)
duration = 5;       % Signal duration (seconds)
t        = 0 : 1/fs : duration - 1/fs;

% Frequencies
f_heart  = 1.2;     % 72 BPM
f_motion = 0.5;     % Motion artifact frequency (Hz) - change from 2.5Hz
f_hum    = 60;      % Powerline hum (60 Hz US, change to 50 for EU)

% Signal amplitudes in mV (after TIA with Rf = 200kΩ, scaled ÷1000)
A_signal = 400;      % Change from ±10 mV  — clean PPG (50µA × 200kΩ ÷ 1000)
A_motion = 800;      % Change from ±20 mV  — motion artifact (larger than signal)
A_hum    = 160;       % Change from ±4 mV  — 60 Hz hum
A_dc     = 0;      %  change from +15 mV — DC ambient light offset

% Professor's component values
R_lpf    = 33e3;    % 33 kΩ  (Sallen-Key LPF)
C_lpf    = 1e-6;    % 1 µF
R_notch  = 27e3;    % 27 kΩ  (Twin-T Notch)
C_notch  = 100e-9;  % 100 nF
bw_notch = 2;       % Notch bandwidth (Hz)

% Compute actual cutoff frequencies from components
fc_lpf   = 1 / (2*pi*R_lpf*C_lpf);     % ≈ 4.82 Hz
f0_notch = 1 / (2*pi*R_notch*C_notch); % ≈ 58.9 Hz


%% =========================================================
%  PHASE 1 — Signal Generation
%  Build the synthetic PPG signal with all noise sources
%% =========================================================

% Individual signal components
ppg_heart  = A_signal * sin(2*pi*f_heart*t);
ppg_motion = A_motion * sin(2*pi*f_motion*t) ...
           + A_motion * 0.3 * randn(size(t));   % motion = sine + random
ppg_hum    = A_hum    * sin(2*pi*f_hum*t);
ppg_dc     = A_dc     * ones(size(t));

% Combined signals
ppg_clean  = ppg_heart + ppg_dc;               % ideal signal (what we want)
ppg_noisy  = ppg_heart + ppg_motion ...        % realistic input to filter
           + ppg_hum   + ppg_dc;

% ---- Figure 1: Clean vs Noisy (time domain) ----
figure('Name','Phase 1 - Signal Generation','NumberTitle','off');

subplot(2,1,1);
plot(t, ppg_clean, 'Color',[0.1 0.6 0.4], 'LineWidth',1.8);
title('Clean PPG signal (simulated heart rate ~72 BPM)');
xlabel('Time (s)'); ylabel('Amplitude (mV)');
grid on;
ylim([A_dc - A_signal*2.5,  A_dc + A_signal*2.5]);   % auto-fit to signal

subplot(2,1,2);
plot(t, ppg_noisy, 'Color',[0.85 0.2 0.1], 'LineWidth',1);
title('Noisy PPG signal (motion artifact + 60 Hz hum + DC offset)');
xlabel('Time (s)'); ylabel('Amplitude (mV)');
grid on;

% ---- Figure 2: FFT of noisy input ----
figure('Name','Phase 1 - Frequency Spectrum (Noisy)','NumberTitle','off');
plotFFT(ppg_noisy, fs, 'Noisy input - frequency spectrum', f_heart, fc_lpf, f_hum);

% Print signal summary
fprintf('\n=== Phase 1: Signal Amplitudes (after TIA, Rf = 200kΩ) ===\n');
fprintf('Heart rate signal : ±%.0f mV  at %.1f Hz\n', A_signal, f_heart);
fprintf('Motion artifact   : ±%.0f mV  at %.1f Hz  (%.0fx larger than signal)\n', ...
        A_motion, f_motion, A_motion/A_signal);
fprintf('60 Hz hum         : ±%.0f mV  at %.0f Hz\n', A_hum, f_hum);
fprintf('DC offset         : +%.0f mV  (ambient light)\n', A_dc);


%% =========================================================
%  PHASE 2 — Filter Design & Application
%% =========================================================

%% 2A — Design LPF: Sallen-Key 2nd order Butterworth
%  R = 33kΩ, C = 1µF → fc = 4.82 Hz
[b_lpf, a_lpf] = butter(2, fc_lpf/(fs/2), 'low');

%% 2B — Design Notch: Twin-T at 60 Hz
%  R = 27kΩ, C = 100nF → f0 ≈ 58.9 Hz
w0 = f0_notch / (fs/2);
bw = bw_notch / (fs/2);
[b_notch, a_notch] = iirnotch(w0, bw); %#ok<IRNCH>

%% 2C — Apply filters (filtfilt = zero phase, no signal distortion)
ppg_after_lpf   = filtfilt(b_lpf,   a_lpf,   ppg_noisy);
ppg_after_notch = filtfilt(b_notch, a_notch, ppg_after_lpf);

% Reference clean signal (DC removed for fair comparison)
ppg_ref    = ppg_heart;   % pure heart rate, no DC
ppg_output = ppg_after_notch - mean(ppg_after_notch);

% ---- Figure 3: Time domain — 3 stages ----
figure('Name','Phase 2 - Filtering Result','NumberTitle','off');

subplot(3,1,1);
plot(t, ppg_noisy, 'Color',[0.85 0.2 0.1], 'LineWidth',1);
title('Input: noisy PPG');
xlabel('Time (s)'); ylabel('Amplitude (mV)'); grid on;

subplot(3,1,2);
plot(t, ppg_after_lpf, 'Color',[0.2 0.4 0.85], 'LineWidth',1.5);
title(sprintf('After LPF  (fc = %.1f Hz  |  Sallen-Key: R=33kΩ, C=1µF)', fc_lpf));
xlabel('Time (s)'); ylabel('Amplitude (mV)'); grid on;

subplot(3,1,3);
plot(t, ppg_output, 'Color',[0.1 0.6 0.4], 'LineWidth',1.8);
hold on;
plot(t, ppg_ref, 'k--', 'LineWidth',1.2);
legend('Filtered output','Original clean signal', 'Location','best');
title(sprintf('After LPF + Notch  (f0 = %.1f Hz  |  Twin-T: R=27kΩ, C=100nF)', f0_notch));
xlabel('Time (s)'); ylabel('Amplitude (mV)'); grid on;

% ---- Figure 4: FFT comparison — 3 stages ----
figure('Name','Phase 2 - FFT Comparison','NumberTitle','off');

subplot(3,1,1);
plotFFT(ppg_noisy,       fs, 'Noisy input spectrum',        f_heart, fc_lpf, f_hum);
subplot(3,1,2);
plotFFT(ppg_after_lpf,   fs, 'After LPF spectrum',          f_heart, fc_lpf, f_hum);
subplot(3,1,3);
plotFFT(ppg_after_notch, fs, 'After LPF + Notch spectrum',  f_heart, fc_lpf, f_hum);

% ---- Figure 5: Bode plot LPF — compare vs LTspice Sallen-Key AC sweep ----
figure('Name','Phase 2 - Bode Plot (LPF)','NumberTitle','off');
freqz(b_lpf, a_lpf, 2048, fs);
sgtitle(sprintf('LPF Bode plot  (fc = %.1f Hz)  —  compare against LTspice Sallen-Key', fc_lpf));

% ---- Figure 6: Bode plot Notch — compare vs LTspice Twin-T AC sweep ----
figure('Name','Phase 2 - Bode Plot (Notch)','NumberTitle','off');
[H_notch, F_notch] = freqz(b_notch, a_notch, 2048, fs);

subplot(2,1,1);
plot(F_notch, 20*log10(abs(H_notch)), 'Color',[0.15 0.35 0.75], 'LineWidth',1.5);
title(sprintf('Notch filter magnitude  (f0 = %.1f Hz)  —  compare against LTspice Twin-T', f0_notch));
xlabel('Frequency (Hz)'); ylabel('Magnitude (dB)');
xlim([0 150]); ylim([-60 5]);
grid on;
xline(f0_notch, '--r', sprintf('%.1f Hz (notch center)', f0_notch), 'LabelVerticalAlignment','bottom');
xline(f_heart,  '--g', sprintf('%.1f Hz (heart rate)', f_heart),   'LabelVerticalAlignment','bottom');

subplot(2,1,2);
plot(F_notch, angle(H_notch)*180/pi, 'Color',[0.15 0.35 0.75], 'LineWidth',1.5);
title('Notch filter phase response');
xlabel('Frequency (Hz)'); ylabel('Phase (degrees)');
xlim([0 150]); ylim([-200 200]);
grid on;
xline(f0_notch, '--r', sprintf('%.1f Hz', f0_notch), 'LabelVerticalAlignment','bottom');

% ---- Figure 7: SNR bar chart ----
stages  = {ppg_noisy, ppg_after_lpf, ppg_after_notch};
labels  = {'Noisy input', 'After LPF', 'After LPF + Notch'};
snr_vals = zeros(1,3);
for i = 1:3
    s   = stages{i};
    s   = s - mean(s);                      % remove DC
    err = s - ppg_ref;                      % difference from clean signal
    snr_vals(i) = 10*log10(var(ppg_ref) / var(err));
end

figure('Name','Phase 2 - SNR Improvement','NumberTitle','off'); % Figure 7
bar(snr_vals, 'FaceColor',[0.1 0.6 0.4], 'EdgeColor','none');
set(gca, 'XTickLabel', labels, 'FontSize', 11);
ylabel('SNR (dB)');
title('Signal-to-Noise Ratio improvement across filter stages');
grid on; ylim([min(snr_vals)-3, max(snr_vals)+5]);
for i = 1:3
    text(i, snr_vals(i)+0.8, sprintf('%.1f dB', snr_vals(i)), ...
         'HorizontalAlignment','center', 'FontWeight','bold', 'FontSize',11);
end
yline(0, '--k', 'SNR = 0 dB', 'LabelHorizontalAlignment','left');


%% =========================================================
%  COMPONENT VALUES SUMMARY (for LTspice)
%% =========================================================

fprintf('\n========== LPF — Sallen-Key 2nd Order ==========\n');
fprintf('Component values : R = 33 kΩ,  C = 1 µF\n');
fprintf('Actual cutoff fc : %.2f Hz\n', fc_lpf);
fprintf('Target           : ~5 Hz  (heart rate max = 4 Hz)\n');
fprintf('Topology         : Sallen-Key equal-component\n');
fprintf('Rolloff          : -40 dB/decade above cutoff\n');

fprintf('\n========== Notch — Twin-T at 60 Hz ==============\n');
fprintf('Component values : R = 27 kΩ,  C = 100 nF\n');
fprintf('Actual center f0 : %.2f Hz\n', f0_notch);
fprintf('Bandwidth        : %.0f Hz\n', bw_notch);
fprintf('Purpose          : Powerline hum only (US 60 Hz)\n');
fprintf('NOT for motion   : Motion is broadband → LPF handles it\n');

fprintf('\n========== SNR Improvement ======================\n');
for i = 1:3
    fprintf('%-20s : %+.1f dB\n', labels{i}, snr_vals(i));
end
fprintf('=================================================\n\n');


%% =========================================================
%  HELPER FUNCTION — FFT plot with frequency markers
%% =========================================================

function plotFFT(signal, fs, ttl, f_hr, f_cut, f_hum)
    N  = length(signal);
    f  = (0:N-1) * (fs/N);
    Y  = abs(fft(signal)) / N;
    plot(f(1:floor(N/2)), Y(1:floor(N/2)), ...
         'Color',[0.15 0.35 0.75], 'LineWidth',1.2);
    title(ttl);
    xlabel('Frequency (Hz)'); ylabel('|Amplitude| (mV)');
    xlim([0 150]); grid on;
    hold on;
    xline(f_hr,  '--r', sprintf('%.1f Hz (HR)',  f_hr),  'LabelVerticalAlignment','bottom');
    xline(f_cut, '--b', sprintf('%.0f Hz (LPF cutoff)', f_cut), 'LabelVerticalAlignment','bottom');
    xline(f_hum, '--m', sprintf('%.0f Hz (hum)', f_hum), 'LabelVerticalAlignment','bottom');
    hold off;
end